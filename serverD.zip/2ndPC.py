from pynput.mouse import Controller
import requests
from pynput import mouse
mouseC=Controller()
a=0
f=requests.get("http://192.168.0.115:8000/command")
while True:
    try:
        f=requests.get("http://192.168.0.115:8000/command")
        print(a)
        a+=1
        data=eval(f.text)
        print(type(data[1][0]))
        pass
        mouseC.move(data[1][0],data[1][1])
        if data[0][0]:
            mouseC.press(mouse.Button.left)
        if not data[0][0]:
            mouseC.release(mouse.Button.left)
        if data[0][1]:
            mouseC.press(mouse.Button.right)
        if not data[0][1]:
            mouseC.release(mouse.Button.right)
        mouseC.scroll(0,data[2])
    except:
        pass
        
