import os
import http.server
import socketserver

PORT = 8000

# Change to the desired directory
os.chdir('./serverD/')

Handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", PORT), Handler) as httpd:
    print(f"Serving at port {PORT}")
    httpd.serve_forever()