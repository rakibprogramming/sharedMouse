from pynput.mouse import Controller
from pynput import mouse
mouseC=Controller()
import time
mouseC.scroll(0,5)
mouseC.release(mouse.Button.left)