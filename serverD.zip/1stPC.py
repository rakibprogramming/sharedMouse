from pynput import mouse
import pyautogui
global mouseLoc
mouseLoc=[]
global data
data=[[False,False],0]
cleftState=False
crightState=False
def run_listener():
    a=0
    global cleftState
    global crightState
    global data
    data=[[False,False],0]
    data[1]=0
    button_state = [False,False]


    def on_click(x, y, button, pressed):
        if button == mouse.Button.left:
            button_state[0] = pressed
            data[0][0]=pressed 
        elif button == mouse.Button.right:
            data[0][1] = pressed  
    
    def on_scroll(x, y, dx, dy):
        data[1]=dy 

    listener = mouse.Listener(on_click=on_click, on_scroll=on_scroll)
    listener.start()

    try:
        while True:
            fileC=open("./serverD/command","w")            
            global mouseLoc
            position = pyautogui.position()
            mouseLoc.append(position)
            dx=0
            dy=0
            if len(mouseLoc) > 3:
                dx=mouseLoc[1][0]-position[0]
                dy=mouseLoc[1][1]-position[1]
                mouseLoc=[]
            leftButstate=str(data[0][0])
            rightButstate=str(data[0][1])
            scrollC="0"
            if not data[1] ==0:
                print("Scrolling")
            
            mouseDistaceX=str(dx)
            mouseDistaceY=str(dy)

            scrollCOndintion=str(data[1])
            theStringeToWrite=f"[[{leftButstate},{rightButstate}],[{mouseDistaceX},{mouseDistaceY}],{scrollCOndintion}]"
            fileC.write(theStringeToWrite)
            


            data[1]=0
            pass
    except KeyboardInterrupt:
        listener.stop()  
        print("Listener stopped.")

    return data

events = run_listener()

